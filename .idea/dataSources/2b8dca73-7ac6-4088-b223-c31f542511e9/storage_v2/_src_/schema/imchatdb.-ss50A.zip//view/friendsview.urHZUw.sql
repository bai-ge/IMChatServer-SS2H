create view friendsview as
  select
    `imchatdb`.`friends`.`id`           AS `id`,
    `imchatdb`.`friends`.`user_id`      AS `user_id`,
    `imchatdb`.`friends`.`friend_id`    AS `friend_id`,
    `imchatdb`.`users`.`name`           AS `name`,
    `imchatdb`.`users`.`alias`          AS `alias`,
    `imchatdb`.`friends`.`friend_alias` AS `friend_alias`,
    `imchatdb`.`friends`.`relate_time`  AS `relate_time`,
    `imchatdb`.`friends`.`state`        AS `state`,
    `imchatdb`.`friends`.`read_state`   AS `read_state`,
    `imchatdb`.`friends`.`remark`       AS `remark`,
    `imchatdb`.`users`.`img_name`       AS `img_name`,
    `imchatdb`.`users`.`device_id`      AS `device_id`
  from (`imchatdb`.`users`
    join `imchatdb`.`friends` on ((`imchatdb`.`users`.`id` = `imchatdb`.`friends`.`friend_id`)));

